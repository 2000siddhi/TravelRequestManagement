import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeReqformComponent } from './employee-reqform.component';

describe('EmployeeReqformComponent', () => {
  let component: EmployeeReqformComponent;
  let fixture: ComponentFixture<EmployeeReqformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeReqformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeReqformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
