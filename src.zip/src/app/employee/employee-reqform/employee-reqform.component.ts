import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-reqform',
  templateUrl: './employee-reqform.component.html',
  styleUrls: ['./employee-reqform.component.css']
})
export class EmployeeReqformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
